#include <proc/sched.h>
#include <proc/proc.h>
#include <device/device.h>
#include <interrupt.h>
#include <device/kbd.h>
#include <mem/paging.h>
#include <mem/palloc.h>
#include <mem/mm.h>
#include <mem/malloc.h>

pid_t do_fork(proc_func func, void* aux)
{
	pid_t pid;
	struct proc_option opt;

	opt.priority = cur_process-> priority;
	pid = proc_create(func, &opt, aux);

	return pid;
}

void do_exit(int status)
{
	cur_process->exit_status = status; 	
	proc_free();						
	do_sched_on_return();				
}

pid_t do_wait(int *status)
{
	while(cur_process->child_pid != -1)
		schedule();

	int pid = cur_process->child_pid;
	cur_process->child_pid = -1;

	extern struct process procs[];
	procs[pid].state = PROC_UNUSED;

	if(!status)
		*status = procs[pid].exit_status;

	return pid;
}

void * do_malloc(int size)
{
	void *result = NULL;
	// Your code goes here....
	printk("Allocating size... : %d\n", size);
	// Implement Buddy system.
	
	printk("Memory Allocated Address : %x ~ %x\n", 0, 0);		// Need modification 

	return result;
}

void do_free(void * st_addr)
{
	// our code goes here....

	printk("Memory Deallocated size : %d(%d)\n", 0,0);
	printk("Memory Deallocated Address : %x\n", 0);			// Need appropriate modification.
	
	// mem_desc checking
}

void do_shutdown(void)
{
	dev_shutdown();
	return;
}

int do_ssuread(void)
{
	return kbd_read_char();
}


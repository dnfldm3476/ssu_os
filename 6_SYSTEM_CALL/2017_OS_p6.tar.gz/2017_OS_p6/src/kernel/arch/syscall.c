#include <syscall.h>
#include <do_syscall.h>
#include <proc/proc.h>

/*
:: Before
// system call number, parameter 1,2,3, -> push to stack
#define syscall0(SYS_NUM) ({				\
		int ret;							\
		__asm__ __volatile(					\
				"pushl %[num]\n\t"			\
				"int $0x30\n\t"				\
				"addl %%esp, 4"				\
				:							\
				: [num] "g" (SYS_NUM)		\
				);							\
		ret;								\
		})

 */

// system call number -> push to stack
// parameters -> assign to register 
// return value -> top of the stack

#define syscall0(SYS_NUM) ({				\
		int ret = 0;				\
		__asm__ __volatile(					\
				""				\
				:  			\
				: 		\
				);							\
		ret;							\
		})

#define syscall1(SYS_NUM, ARG0) ({				\
		int ret = 0;								\
		__asm__ __volatile(						\
				""					\
				: 							\
				: 				\
				);							\
		ret;	\
		})

#define syscall2(SYS_NUM, ARG0, ARG1) ({		\
		int ret = 0;								\
		__asm__ __volatile(						\
				""			\
				:					\
				:			\
				);							\
		ret;	\	
		})

#define syscall3(SYS_NUM, ARG0, ARG1, ARG2) ({	\
		int ret = 0;								\
		__asm__ __volatile(						\
				""			\
				: 						\
				: 		\
				);							\
		ret;	\
		})

int syscall_tbl[SYS_NUM][2];

#define REGSYS(NUM, FUNC, ARG) \
	syscall_tbl[NUM][0] = (int)FUNC; \
syscall_tbl[NUM][1] = ARG; 

void init_syscall(void)
{
	REGSYS(SYS_FORK, do_fork, 2);
	REGSYS(SYS_EXIT, do_exit, 1);
	REGSYS(SYS_WAIT, do_wait, 1);
	REGSYS(SYS_SSUREAD, do_ssuread, 0);
	REGSYS(SYS_SHUTDOWN, do_shutdown, 0);
	// Your code goes here...
}

void exit(int status)
{
	syscall1(SYS_EXIT, status);
}

pid_t fork(proc_func func, void* aux)
{
	return syscall2(SYS_FORK, func, aux);
}

pid_t wait(int *status)
{
	return syscall1(SYS_WAIT, status);
}

void* malloc(int size)
{
	// Your code goes here...
}

void free(void * mem_addr)
{
    // Your code goes here...
}

int ssuread()
{
	return syscall0(SYS_SSUREAD);
}

void shutdown(void)
{
	syscall0(SYS_SHUTDOWN);
}

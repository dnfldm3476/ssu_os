#include <mem/malloc.h>
#include <debug.h>
#include <list.h>
#include <round.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <mem/palloc.h>
#include <mem/paging.h>
#include <synch.h>

extern struct mem_desc desc_list[MAX_NUM_DESC];
extern struct block_desc blk_list[MAX_BLOCK_DESC];
extern int mem_desc_cnt;
extern int blk_desc_cnt;

void *block_getaddr(void *, int);

void init_malloc(void)
{
	int i;
	void * init_addr;

	for (i = 0; i < MAX_NUM_DESC; i++) 
		desc_list[i].cur_using = 0;
	
	for (i = 0; i < MAX_BLOCK_DESC; i++) 
		blk_list[i].cur_using = 0;

	mem_desc_cnt = 0;
	blk_desc_cnt = 0;

	init_addr = (void *) palloc_get_page();
	desc_list[mem_desc_cnt].page_start = init_addr;
	desc_list[mem_desc_cnt].page_end = init_addr + PAGE_SIZE;
	desc_list[mem_desc_cnt].cur_using = 1;
	
	printk("Mem addr start : %X\n", desc_list[mem_desc_cnt].page_start);
	printk("Mem addr end : %X\n", desc_list[mem_desc_cnt].page_end);
	mem_desc_cnt++;
}

// Find 2^n < req_size <= 2<n+1, and returns 2^n+1.
// Parameters : req_size = requested memory size by process.
// Return value : 
int get_ceiling(int req_size) 
{
	int ruler = 64;
	while ((ruler < req_size) && (ruler < PAGE_SIZE))	ruler *= 2;
	return ruler;
}

// Browse all memory descriptor and find appropriate address of block which size is 'blk_size'. 
// Parameters : blk_size = the size of block that was calculated by 'get_ceiling()'.
// Return value : returns available address in memory descryptor on success, returns NULL on failure.
void* block_checking(int blk_size)
{
    /* Your code goes here... */

}

// Find appropriate location of block in page.
// Parameters : page_addr = start address of page, blk_size = the size of block.
// Return value : returns available address in memory descryptor on success, returns NULL on failure.
void* block_getaddr(void *page_addr, int blk_size)
{
    /*Your code goes here...*/

}
